class Student {
  final String username;
  final String name;
  final String batch;
  final String mentorName;
  final String qrToken;
  final String url;
  final String sts;
  final String inTime;
  final String lastScan;

  Student({
    required this.username,
    required this.name,
    required this.batch,
    required this.mentorName,
    required this.qrToken,
    required this.url,
    required this.sts,
    required this.inTime,
    required this.lastScan,
  });

  factory Student.fromJson(Map<String, dynamic> json) {
    return Student(
      username: json['Username'] ?? '',
      name: json['Name'] ?? '',
      batch: json['Batch'] ?? '',
      mentorName: json['Mentor Name'] ?? '',
      qrToken: json['qr_token'] ?? '',
      url: json['url'] ?? '',
      sts: json['sts'] ?? '',
      inTime: json['in_time'] ?? '',
      lastScan: json['last_scan'] ?? '',
    );
  }
}
