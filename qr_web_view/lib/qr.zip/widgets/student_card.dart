import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../models/student_model.dart';

class StudentCard extends StatelessWidget {
  final Student student;

  const StudentCard({super.key, required this.student});

  @override
  Widget build(BuildContext context) {
    final qrData = {
      "Username": student.username,
      "Name": student.name,
      "Batch": student.batch,
      "Mentor Name": student.mentorName,
      "qr_token": student.qrToken,
      "url": student.url,
      "sts": student.sts,
      "in_time": student.inTime,
      "last_scan": student.lastScan,
    };

    return Center(
      child: Card(
        elevation: 10,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.all(24),
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(student.name, style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 8),
              Text("Username: ${student.username}", style: Theme.of(context).textTheme.bodyLarge),
              Text("Batch: ${student.batch}"),
              Text("Mentor: ${student.mentorName}"),
              const SizedBox(height: 24),
              QrImageView(
                data: qrData.toString(), 
                version: QrVersions.auto,
                size: 250,
              ),
              const SizedBox(height: 16),
             
            ],
          ),
        ),
      ),
    );
  }
}
