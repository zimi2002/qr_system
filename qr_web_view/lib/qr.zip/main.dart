import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:qr_web_view/pages/student_page.dart';

void main() {
  runApp(const MyApp());
}

final GoRouter _router = GoRouter(
  debugLogDiagnostics: true,
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      redirect: (context, state) {
        final qrToken = state.uri.queryParameters['qr_token'];
        debugPrint('=============== Root Redirect ===============');
        debugPrint('URI: ${state.uri}');
        debugPrint('QR Token: $qrToken');

        if (qrToken != null && qrToken.isNotEmpty) {
          debugPrint('Redirecting to student route');
          return '/student?qr_token=$qrToken';
        }
        debugPrint('Staying at root route');
        return null;
      },
      builder: (context, state) {
        debugPrint('Building root route');
        return const Scaffold(
          body: Center(child: Text('Please provide a QR token')),
        );
      },
    ),
    GoRoute(
      path: '/student',
      name: 'student',
      redirect: (context, state) {
        final qrToken = state.uri.queryParameters['qr_token'];
        debugPrint('=============== Student Redirect ===============');
        debugPrint('URI: ${state.uri}');
        debugPrint('QR Token: $qrToken');

        if (qrToken == null || qrToken.isEmpty) {
          debugPrint('No token, redirecting to root');
          return '/';
        }
        return null;
      },
      builder: (context, state) {
        final qrToken = state.uri.queryParameters['qr_token'];
        debugPrint('Building student route with token: $qrToken');
        return StudentPage(qrToken: qrToken);
      },
    ),
  ],
);

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      routerConfig: _router,
      title: 'QR Student View',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // TRY THIS: Try running your application with "flutter run". You'll see
        // the application has a purple toolbar. Then, without quitting the app,
        // try changing the seedColor in the colorScheme below to Colors.green
        // and then invoke "hot reload" (save your changes or press the "hot
        // reload" button in a Flutter-supported IDE, or press "r" if you used
        // the command line to start the app).
        //
        // Notice that the counter didn't reset back to zero; the application
        // state is not lost during the reload. To reset the state, use hot
        // restart instead.
        //
        // This works for code too, not just values: Most code changes can be
        // tested with just a hot reload.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
    );
  }
}
