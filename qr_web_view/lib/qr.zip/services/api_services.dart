import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/student_model.dart';

class ApiService {
  static const String baseUrl = "https://script.google.com/macros/s/AKfycbxcuNrfWgnLvFL1oyneF_sPXOmYeoYb7gupIU5tL4B3dzQYBJhyYEY_rsV17CuqrFz04A/exec";

  static Future<Student?> fetchStudent(String qrToken) async {
    final response = await http.get(Uri.parse('$baseUrl?qr_token=$qrToken'));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['success'] == true && data['count'] > 0) {
        return Student.fromJson(data['data'][0]);
      }
    }
    return null;
  }
}