import 'package:flutter/material.dart';
import 'package:qr_web_view/services/api_services.dart';
import '../models/student_model.dart';
import '../widgets/student_card.dart';

class StudentPage extends StatefulWidget {
  final String? qrToken;

  const StudentPage({super.key, this.qrToken});

  @override
  State<StudentPage> createState() => _StudentPageState();
}

class _StudentPageState extends State<StudentPage> {
  Student? student;
  bool isLoading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _loadStudent();
  }

  void _loadStudent() async {
    if (widget.qrToken == null || widget.qrToken!.isEmpty) {
      setState(() {
        error = 'No qr_token provided in URL.';
        isLoading = false;
      });
      return;
    }

    final result = await ApiService.fetchStudent(widget.qrToken!);
    setState(() {
      if (result != null) {
        student = result;
      } else {
        error = 'No student found for this QR token.';
      }
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Student QR Page')),
      body: Center(
        child: isLoading
            ? const CircularProgressIndicator()
            : (student != null
                  ? StudentCard(student: student!)
                  : Text(error ?? 'Error loading data')),
      ),
    );
  }
}
